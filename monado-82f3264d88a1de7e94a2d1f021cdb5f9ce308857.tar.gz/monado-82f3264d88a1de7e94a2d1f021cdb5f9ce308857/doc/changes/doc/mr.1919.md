README: Clarify Vulkan SDK requirement on Windows.

README: Add some Debian/Ubuntu packages.

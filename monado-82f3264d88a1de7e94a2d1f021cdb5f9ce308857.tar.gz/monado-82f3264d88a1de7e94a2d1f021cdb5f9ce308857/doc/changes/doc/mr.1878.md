Add documentation category in changelog documentation.

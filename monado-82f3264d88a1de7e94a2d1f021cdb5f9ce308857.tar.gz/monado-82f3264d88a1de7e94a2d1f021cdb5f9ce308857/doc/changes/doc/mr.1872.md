---
- mr.2120
---
Add documentation for how to write changelogs in the @ref conventions page.

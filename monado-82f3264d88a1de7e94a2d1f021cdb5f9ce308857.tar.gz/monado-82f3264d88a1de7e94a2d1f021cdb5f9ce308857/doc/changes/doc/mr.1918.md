README: Add Debian/Ubuntu package for libudev.

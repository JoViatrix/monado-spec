Don't build documentation by default, it is fairly heavy for end users. Also
makes the CI scripts cleaner as they don't need to disabled it everywhere.

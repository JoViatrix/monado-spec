u/trace_marker: Add sink categories.

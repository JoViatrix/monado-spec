vk: Print out information about the opened device.

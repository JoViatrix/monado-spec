vk: Refactor out bundle functions into a file of their own.

bindings: Add OPPO MR controller profile.

u/builders: Refactor space overseer creation helper.

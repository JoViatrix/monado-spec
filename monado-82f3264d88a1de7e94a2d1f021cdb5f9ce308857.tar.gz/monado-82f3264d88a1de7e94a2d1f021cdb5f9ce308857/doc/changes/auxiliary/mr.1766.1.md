vk: Add new cmd buffer helper file `vk_cmd.[h|c]`, these does not use the global
command pool.

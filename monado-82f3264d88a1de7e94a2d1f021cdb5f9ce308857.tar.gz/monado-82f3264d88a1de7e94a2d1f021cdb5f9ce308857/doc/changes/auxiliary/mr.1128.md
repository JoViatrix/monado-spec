vk: Refactor and rename various function related to compositor swapchain
images and their flags, these changes makes it clear it's only used for these
images and image views.

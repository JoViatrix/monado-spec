u/space: Fix build warning because of non-void function not returning

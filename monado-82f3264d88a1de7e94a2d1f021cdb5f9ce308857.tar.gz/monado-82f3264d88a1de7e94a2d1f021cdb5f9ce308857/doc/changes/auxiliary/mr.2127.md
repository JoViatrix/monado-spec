os/threading: fix assert in debug build

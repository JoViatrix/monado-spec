t/hsv: Add tracing support for timing info.

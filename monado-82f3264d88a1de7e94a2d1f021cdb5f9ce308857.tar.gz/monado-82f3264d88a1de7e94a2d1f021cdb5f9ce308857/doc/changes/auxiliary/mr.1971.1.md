---
- mr.1971
- mr.1417
---

vk: Rename and add more variants of return checking defines, making the define
now be all caps so it's easier to see if it effects flow control.

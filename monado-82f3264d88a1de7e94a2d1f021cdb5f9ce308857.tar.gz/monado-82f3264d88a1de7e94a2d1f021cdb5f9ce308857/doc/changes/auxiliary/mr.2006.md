---
- mr.2006
- mr.2014
---

vk: Change the naming function to use the extension `VK_EXT_debug_utils`, which
has been included in core with 1.3, instead of the old `VK_EXT_debug_marker`
extension. Also make the naming function type safe.

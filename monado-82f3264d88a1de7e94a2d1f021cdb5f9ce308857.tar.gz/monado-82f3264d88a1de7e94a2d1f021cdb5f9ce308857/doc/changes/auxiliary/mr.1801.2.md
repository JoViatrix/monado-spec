u/pacing: Add variable tracking to fake pacer.

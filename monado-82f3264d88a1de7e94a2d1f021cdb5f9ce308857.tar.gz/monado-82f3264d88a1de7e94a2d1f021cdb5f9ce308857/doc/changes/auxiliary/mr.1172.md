t/cli: Add monado-cli slambatch command for evaluation of SLAM datasets in
batch.

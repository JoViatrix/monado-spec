t/file: Migrate calibration file format to JSON.

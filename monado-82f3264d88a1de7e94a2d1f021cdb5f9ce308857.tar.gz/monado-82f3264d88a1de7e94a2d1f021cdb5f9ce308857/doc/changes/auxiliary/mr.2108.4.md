u/pacing: Do live stats tracking in fake pacer.

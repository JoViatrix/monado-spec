math: Refactor m_clock_offset_a2b to avoid precision problems.

u/sink: Add tracing support to sink functions.

t/euroc: Allow euroc recorder to start and stop recordings in the same session

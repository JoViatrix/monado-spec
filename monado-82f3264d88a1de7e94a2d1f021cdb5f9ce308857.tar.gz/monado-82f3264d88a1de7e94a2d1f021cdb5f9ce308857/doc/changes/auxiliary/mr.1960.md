vive: Fix use after free, probably left over since refactor.

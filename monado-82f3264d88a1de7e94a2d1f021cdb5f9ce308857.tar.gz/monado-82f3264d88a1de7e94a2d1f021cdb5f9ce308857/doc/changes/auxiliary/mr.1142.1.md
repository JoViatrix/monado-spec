vk: Check which fence types can be imported and exported on the device.

vive: Move the view fov calculation into the config file helper.

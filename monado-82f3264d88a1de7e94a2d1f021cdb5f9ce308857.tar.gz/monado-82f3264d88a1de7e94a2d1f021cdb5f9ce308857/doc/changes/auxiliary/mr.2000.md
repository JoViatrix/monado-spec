 t/slam: Use locks for CSV writers

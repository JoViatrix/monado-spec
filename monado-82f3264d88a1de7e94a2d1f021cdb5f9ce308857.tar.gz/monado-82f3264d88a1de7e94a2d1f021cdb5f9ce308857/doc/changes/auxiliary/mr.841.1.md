vk: Add more functions to vk_bundle struct.

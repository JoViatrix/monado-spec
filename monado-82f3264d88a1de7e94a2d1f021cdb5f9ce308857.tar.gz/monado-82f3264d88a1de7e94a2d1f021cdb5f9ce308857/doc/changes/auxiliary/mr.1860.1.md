bindings: Add generic vive tracker input and output bindings, not used for now.

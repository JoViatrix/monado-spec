u/aeg: Implement module for auto exposure and gain to help with SLAM tracking.

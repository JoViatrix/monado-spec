vk: Add support for VK_EXT_robustness2

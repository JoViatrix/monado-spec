m/3dof: Add assert to catch time traveling drivers.

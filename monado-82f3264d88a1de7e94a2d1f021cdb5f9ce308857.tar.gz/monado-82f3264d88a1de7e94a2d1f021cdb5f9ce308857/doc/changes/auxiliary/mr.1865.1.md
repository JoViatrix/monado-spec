---
- mr.1865
- mr.1923
---

u/truncate_printf: Add helpers that have the semantics we want for the printf
functions [vn|sn]printf.

u/file: Search more paths, and actually test if a directory is there, for
hand-tracking models.

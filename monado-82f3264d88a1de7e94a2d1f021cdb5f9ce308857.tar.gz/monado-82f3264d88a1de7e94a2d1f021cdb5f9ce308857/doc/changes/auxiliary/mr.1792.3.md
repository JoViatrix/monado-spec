vive: Add hardcoded tweaks for view FoV values.

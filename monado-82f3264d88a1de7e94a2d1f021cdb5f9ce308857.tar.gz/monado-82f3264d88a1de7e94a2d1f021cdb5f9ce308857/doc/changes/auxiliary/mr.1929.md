vive: Add C++ guards to poses header.

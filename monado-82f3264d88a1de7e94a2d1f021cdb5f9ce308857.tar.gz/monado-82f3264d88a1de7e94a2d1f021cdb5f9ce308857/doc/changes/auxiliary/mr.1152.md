t/slam: Add tools for performance and accuracy evaluation of the SLAM tracker.

vive: Add builder helper to allow sharing of estimation code.

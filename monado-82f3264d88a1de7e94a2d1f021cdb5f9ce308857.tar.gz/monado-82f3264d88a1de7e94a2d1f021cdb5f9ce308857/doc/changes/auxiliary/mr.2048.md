u/space_overseer: Add support for reference space usage.

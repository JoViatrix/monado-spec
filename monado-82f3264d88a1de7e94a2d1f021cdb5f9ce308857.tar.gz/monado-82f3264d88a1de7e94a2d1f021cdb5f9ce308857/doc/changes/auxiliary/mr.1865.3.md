---
- mr.1865
- mr.1892
---

u/logging: Refactor printing to be safer using truncating helpers, and increase
the reuse of code.

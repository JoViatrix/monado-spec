u/space_overseer: Implement recentering for supported setups.

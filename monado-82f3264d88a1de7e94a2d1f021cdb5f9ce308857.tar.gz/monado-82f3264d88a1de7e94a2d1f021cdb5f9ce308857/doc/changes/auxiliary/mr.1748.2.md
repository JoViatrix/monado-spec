vk: Remove the global command buffer pool.

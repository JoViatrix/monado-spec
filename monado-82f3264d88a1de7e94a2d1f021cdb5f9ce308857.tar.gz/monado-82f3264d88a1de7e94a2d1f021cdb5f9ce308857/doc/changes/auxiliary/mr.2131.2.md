t/slam: Send hand tracking masks to VIT system

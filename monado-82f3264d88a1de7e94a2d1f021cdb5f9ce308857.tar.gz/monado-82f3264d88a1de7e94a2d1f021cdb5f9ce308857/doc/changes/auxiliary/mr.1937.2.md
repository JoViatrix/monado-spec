a/vive: Add FoV tweaks for another index HMD

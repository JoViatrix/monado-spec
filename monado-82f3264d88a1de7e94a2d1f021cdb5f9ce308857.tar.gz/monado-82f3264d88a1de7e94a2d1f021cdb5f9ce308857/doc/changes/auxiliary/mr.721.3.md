u/timing: A rather large refactor that turns makes the rendering timing helper
be more like the frame timing helper. This also makes the rendering timing
adjust the frame timing of the app so that latency is reduced.

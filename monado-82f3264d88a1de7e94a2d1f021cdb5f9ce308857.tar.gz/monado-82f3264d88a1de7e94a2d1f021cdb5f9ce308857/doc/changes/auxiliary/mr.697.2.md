u/pacing: Add frame timing helper code designed to use Vulkan display timing
extensions to get proper frame timing in the compositor.

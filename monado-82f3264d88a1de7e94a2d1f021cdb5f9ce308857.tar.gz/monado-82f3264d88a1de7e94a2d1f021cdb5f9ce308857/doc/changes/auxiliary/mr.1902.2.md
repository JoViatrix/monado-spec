u/var: Refactor code to make it easier to search for number objects.

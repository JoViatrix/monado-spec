u/pacing: Add minimum compositor frame time.

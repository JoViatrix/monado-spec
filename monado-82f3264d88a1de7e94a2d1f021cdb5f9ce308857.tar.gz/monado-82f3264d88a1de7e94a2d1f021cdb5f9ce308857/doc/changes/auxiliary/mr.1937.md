h/mercury: Add min detection confidence option

u/pp: Add `xrt_reference_space_type` printing.

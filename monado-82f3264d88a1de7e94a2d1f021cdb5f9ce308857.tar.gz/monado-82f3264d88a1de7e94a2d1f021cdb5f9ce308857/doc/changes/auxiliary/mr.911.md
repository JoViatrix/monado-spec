t/calibration: Add support for findChessboardCornersSB in calibration code.

u/var: Improve documentation and make `suffix_with_number` argument clearer.

u/logging: Fix the first message always getting printed due to un-initialized
variable.

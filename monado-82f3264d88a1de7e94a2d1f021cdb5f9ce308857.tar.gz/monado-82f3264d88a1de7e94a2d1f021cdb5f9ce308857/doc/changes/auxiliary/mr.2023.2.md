u/device: Improve comment on u_device_get_view_poses.

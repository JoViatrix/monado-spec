u/pacing: Predict present time and then calculate display time in fake pacer.

a/util: Fixes crash bug with XR_EXT_dpad_binding after multiple session re-runs.

t/slam: Add basic tracing support.

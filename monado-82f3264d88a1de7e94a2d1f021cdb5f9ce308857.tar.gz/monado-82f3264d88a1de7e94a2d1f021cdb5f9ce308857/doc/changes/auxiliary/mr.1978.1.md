math: Minor tidy of `m_api.h`, `m_base.cpp` and `CMakeLists.txt`.

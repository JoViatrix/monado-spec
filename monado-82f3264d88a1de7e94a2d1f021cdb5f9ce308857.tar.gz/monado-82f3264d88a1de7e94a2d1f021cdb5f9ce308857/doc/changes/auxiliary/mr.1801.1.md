vk: Add vk_surface_info helper for VkSurfaceKHR information gathering.

vk: Refactor `vk_csci_get_image_usage_flags` to not always set the sampled bit
and other bits that where always set. Also tidy with a nice define for checking.

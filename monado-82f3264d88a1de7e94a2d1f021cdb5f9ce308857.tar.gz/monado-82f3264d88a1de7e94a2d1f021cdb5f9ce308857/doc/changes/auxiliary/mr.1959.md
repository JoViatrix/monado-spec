vk: Init vk bundle with shaderImageGatherExtended enabled if supported.

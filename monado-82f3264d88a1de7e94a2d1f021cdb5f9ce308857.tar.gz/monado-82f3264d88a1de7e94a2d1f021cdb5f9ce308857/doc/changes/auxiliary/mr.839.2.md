math: Add `math_map_ranges` function, does the same thing as Arduino's `map`.

math: Fixes for M_PI on Windows.

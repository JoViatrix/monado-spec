util: Add code to get a limited unique id, it's a simple 64 bit atomic counter.

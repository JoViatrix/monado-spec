u/windows: Add helper code for various bits of Windows related things, like
formatting error numbers into error messages. Also functions related to
cpu priority and privilege granting of rights.

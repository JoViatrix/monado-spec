u/logging: Add json logging, it can be enabled via the XRT_JSON_LOG env var.

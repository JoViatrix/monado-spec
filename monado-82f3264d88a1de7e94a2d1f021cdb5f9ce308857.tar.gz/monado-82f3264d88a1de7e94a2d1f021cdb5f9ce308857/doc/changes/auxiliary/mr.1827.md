u/var: Improve documentation.

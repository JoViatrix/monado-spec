vk: Add copy and blit command buffer writer helpers to `vk_cmd.[h|c]`.

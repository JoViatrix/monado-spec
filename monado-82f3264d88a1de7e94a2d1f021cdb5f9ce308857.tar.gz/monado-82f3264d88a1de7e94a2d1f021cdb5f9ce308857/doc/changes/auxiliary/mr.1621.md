u/space_overseer: Make it possible set root as unbounded.

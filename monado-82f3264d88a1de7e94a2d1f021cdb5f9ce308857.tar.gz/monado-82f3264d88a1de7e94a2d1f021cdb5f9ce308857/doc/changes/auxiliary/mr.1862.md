vive: Refactor documentation and move VID and PID defines here.

t/euroc: Add EuRoC dataset recorder for saving camera and IMU streams to disk.

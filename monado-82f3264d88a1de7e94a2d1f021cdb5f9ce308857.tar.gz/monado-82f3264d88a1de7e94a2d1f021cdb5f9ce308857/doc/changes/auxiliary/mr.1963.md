android: Support creating surface with title.

---
- mr.2049
- mr.2100
---

vk: Use formats list from xrt_swapchain_create_info in create_image.

vk: Fix swapchain leak on Android due to it having different Vulkan import behavior.

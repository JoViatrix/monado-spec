vk: Add helpers to manage command buffers and create various state objects.

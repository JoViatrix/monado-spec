vk: Make sure to print the first GPU as well when selecting physical device.

t/slam: Update to VIT 1.0.1 with small usage improvements

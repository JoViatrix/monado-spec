vk: Pass create mutable format bit if usage flag is set.

u/pp: Tidy and add more entries to enum printing functions.

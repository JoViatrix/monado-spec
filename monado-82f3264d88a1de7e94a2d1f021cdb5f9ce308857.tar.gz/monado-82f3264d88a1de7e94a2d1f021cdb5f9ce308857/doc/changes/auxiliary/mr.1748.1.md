vk: Add new command buffer helpers and `vk_cmd_pool` helper class.

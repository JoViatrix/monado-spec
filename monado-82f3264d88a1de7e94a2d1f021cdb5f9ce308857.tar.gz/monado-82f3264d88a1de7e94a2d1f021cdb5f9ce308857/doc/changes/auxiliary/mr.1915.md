bindings: Replaces the `monado_device` entry for `XR_EXT_hand_interaction` in
bindings.json to refer to a new device name type.

pacing: Add minimum app margin, also add `U_PACING_APP_MIN_MARGIN_MS` env var.

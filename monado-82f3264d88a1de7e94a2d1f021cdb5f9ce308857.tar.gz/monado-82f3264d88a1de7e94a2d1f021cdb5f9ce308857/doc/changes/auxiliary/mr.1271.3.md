u/pacing: Make the comp time be at least 2ms in fake pacer, this is a more
conservative margin for when the fake pacer is used for real hardware.

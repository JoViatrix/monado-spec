ogl: Add various helper functions, and tidy code a bit.

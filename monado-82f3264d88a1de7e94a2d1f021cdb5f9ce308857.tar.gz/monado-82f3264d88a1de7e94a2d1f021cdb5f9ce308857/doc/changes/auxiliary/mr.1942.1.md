vk: When listing GPUs also write out device type.

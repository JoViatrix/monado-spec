u/pacing: Make present_to_display_offset_ns more clear by changing the name.

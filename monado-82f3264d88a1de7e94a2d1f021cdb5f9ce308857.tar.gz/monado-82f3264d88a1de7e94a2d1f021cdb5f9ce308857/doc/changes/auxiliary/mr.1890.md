bindings: Correct ML2 controller extension string.

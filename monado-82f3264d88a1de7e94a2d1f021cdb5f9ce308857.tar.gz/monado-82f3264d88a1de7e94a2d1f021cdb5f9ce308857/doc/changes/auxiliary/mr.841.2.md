vk: Make it possible to create a compute only queue.

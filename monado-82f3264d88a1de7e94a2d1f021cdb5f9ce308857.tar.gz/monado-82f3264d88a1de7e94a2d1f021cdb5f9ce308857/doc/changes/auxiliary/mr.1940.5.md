vk: Add printers for VkSurface and VkSwapchain create info structs.

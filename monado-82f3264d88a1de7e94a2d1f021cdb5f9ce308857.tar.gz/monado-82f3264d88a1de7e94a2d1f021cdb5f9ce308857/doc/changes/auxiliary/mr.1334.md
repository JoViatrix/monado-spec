t/slam: Support calibration info from drivers and sending it to the external
SLAM system.

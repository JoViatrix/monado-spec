vk: Add fence import function.

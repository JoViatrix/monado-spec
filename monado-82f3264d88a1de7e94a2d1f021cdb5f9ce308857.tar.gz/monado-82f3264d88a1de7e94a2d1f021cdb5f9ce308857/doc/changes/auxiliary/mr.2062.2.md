u/session: Add helper to implement `xrt_session`.

vive: Add support for Gen 3.0 and Tundra trackers.

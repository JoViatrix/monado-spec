u/generic_callbacks: Fix missing include for generic callback structure.

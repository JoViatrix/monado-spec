u/logging: Log to stderr in Windows.

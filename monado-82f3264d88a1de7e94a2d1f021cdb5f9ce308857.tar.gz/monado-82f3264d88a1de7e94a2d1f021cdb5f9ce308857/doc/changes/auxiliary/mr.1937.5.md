t/slam: Turn timestamp asserts into warnings

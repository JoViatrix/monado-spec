t/slam: Add Basalt as a possible external SLAM system.

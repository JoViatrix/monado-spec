all: Rename all `num_` parameters and fields, typically to `_count`, to match
OpenXR convention.

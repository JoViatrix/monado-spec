u/space_overseer: Use broadcast event sink for reference space changes,
generates `xrt_session_event_reference_space_change_pending` events.

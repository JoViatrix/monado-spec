u/device: Added `u_device_2d_extents` and
`u_setup_2d_extents_split_side_by_side`, this is hopefully to eliminate
confusion: the FOV you had to give to `u_device_split_side_by_side` was a
placeholder value, but some people thought it was the actual headset's FOV.

---
- mr.1809
- mr.1828
---

u/pacing: Add minimum application frame time.

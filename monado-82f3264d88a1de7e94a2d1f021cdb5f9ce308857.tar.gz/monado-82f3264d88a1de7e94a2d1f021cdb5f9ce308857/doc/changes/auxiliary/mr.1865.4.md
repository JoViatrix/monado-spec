u/logging: Make the CMake variable only be true on Linux.

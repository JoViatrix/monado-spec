os/time: Use timePeriod[Begin|End] when sleeping in precise sleeper

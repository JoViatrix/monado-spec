t/slam: Update SLAM interface to support dynamically query external systems for
special features.

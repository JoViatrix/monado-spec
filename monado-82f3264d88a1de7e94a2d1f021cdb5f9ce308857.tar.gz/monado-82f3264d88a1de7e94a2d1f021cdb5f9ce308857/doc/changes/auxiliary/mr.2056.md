tracking: Tidy and improve `xrt::auxiliary::tracking::FrameMat`.

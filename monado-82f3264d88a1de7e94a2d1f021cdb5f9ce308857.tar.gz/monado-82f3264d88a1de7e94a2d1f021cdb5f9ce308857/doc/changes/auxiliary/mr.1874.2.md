u/debug: Use system properties on Android for the debug settings, properties
are prefixed with `debug.xrt.` so the property for `XRT_LOG` is
`debug.xrt.XRT_LOG`.

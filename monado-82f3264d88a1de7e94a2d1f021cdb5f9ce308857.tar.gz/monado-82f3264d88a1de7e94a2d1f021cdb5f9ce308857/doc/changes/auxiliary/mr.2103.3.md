u/var: Add `u_native_images_debug` as a tracked variable.

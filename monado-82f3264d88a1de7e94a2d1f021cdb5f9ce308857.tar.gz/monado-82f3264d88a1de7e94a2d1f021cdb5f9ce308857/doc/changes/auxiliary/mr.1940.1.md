vk: Add more enumeration helpers.

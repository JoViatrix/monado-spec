vk: Refactor and tidy extension handling.

t/calibration: Make it possible to select number distortion parameters.

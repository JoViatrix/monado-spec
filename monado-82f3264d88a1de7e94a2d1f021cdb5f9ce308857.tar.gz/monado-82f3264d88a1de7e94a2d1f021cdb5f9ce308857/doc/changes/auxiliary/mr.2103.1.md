vk: Return `VK_FORMAT_FEATURE_STORAGE_IMAGE_BIT` for
`XRT_SWAPCHAIN_USAGE_UNORDERED_ACCESS` from `vk_csci_get_image_usage_flags`.

system_helpers: Make system devices easier to embed.

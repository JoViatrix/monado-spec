u/pacing: Add variable tracking integration to app pacer.

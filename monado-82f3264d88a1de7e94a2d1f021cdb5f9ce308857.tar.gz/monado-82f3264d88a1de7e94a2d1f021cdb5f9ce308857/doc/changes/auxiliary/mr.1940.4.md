vk: Print more VkSurface info.

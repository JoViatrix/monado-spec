vk: Add code to handle optional device features.

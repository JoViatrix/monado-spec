t/slam: Add trajectory filters and use IMU for prediction in the SLAM tracker.

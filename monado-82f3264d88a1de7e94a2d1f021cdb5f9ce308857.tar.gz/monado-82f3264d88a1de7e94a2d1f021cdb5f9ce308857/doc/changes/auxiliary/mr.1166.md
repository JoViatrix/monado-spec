vk: Add `XRT_CHECK_RESULT` to sync functions.

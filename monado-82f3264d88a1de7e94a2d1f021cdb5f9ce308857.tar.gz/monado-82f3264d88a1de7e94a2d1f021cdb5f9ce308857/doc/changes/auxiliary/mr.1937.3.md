external/slam: Update to 7.0.0 with RESET_TRACKER_STATE and ignore masks

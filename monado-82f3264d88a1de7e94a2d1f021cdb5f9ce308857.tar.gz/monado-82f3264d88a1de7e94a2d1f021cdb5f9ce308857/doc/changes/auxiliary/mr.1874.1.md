u/debug: Refactor code to be prettier and expose more conversion functions.

vk: Relax the compute-only queue search to fall back to any queue that supports
compute.

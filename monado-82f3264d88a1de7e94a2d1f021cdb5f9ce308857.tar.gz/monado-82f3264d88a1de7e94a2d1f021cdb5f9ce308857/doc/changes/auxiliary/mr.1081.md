---
- mr.1081
- mr.1104
---

u/pacing: Renames and improvements for frame pacing (formerly known as render
and display timing) code and APIs.

---
- mr.1885
- mr.1973
---

vk: Add function to check required instance extensions.

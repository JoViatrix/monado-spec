t/slam: Initial external SLAM tracking support, working with fork of Kimera-VIO.

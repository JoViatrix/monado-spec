vk: Add two mini define helpers in their own header (`D` and `DF`) which was
redefined in multiple places in the source code. Keep in own header to not
clutter namespace.

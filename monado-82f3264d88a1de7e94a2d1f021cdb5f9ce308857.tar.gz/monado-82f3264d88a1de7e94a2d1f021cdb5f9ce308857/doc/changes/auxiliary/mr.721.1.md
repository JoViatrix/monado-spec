u/time: Add helper comparison functions.

u/space_overseer: Notify the device about reference space usage.

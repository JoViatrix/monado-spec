math: Add function to calculate a vulkan infinite reverse projection matrix.

bindings: Add support for eye gaze bindings extension.

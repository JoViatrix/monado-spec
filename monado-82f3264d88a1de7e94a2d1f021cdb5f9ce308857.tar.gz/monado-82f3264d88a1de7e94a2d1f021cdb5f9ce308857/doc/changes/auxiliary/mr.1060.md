t/slam: Add naive prediction to the SLAM tracker.

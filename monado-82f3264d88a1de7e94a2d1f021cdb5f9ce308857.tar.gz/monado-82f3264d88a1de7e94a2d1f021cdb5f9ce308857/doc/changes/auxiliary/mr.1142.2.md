vk: Add functions to create, submit and then export a fence native handle.

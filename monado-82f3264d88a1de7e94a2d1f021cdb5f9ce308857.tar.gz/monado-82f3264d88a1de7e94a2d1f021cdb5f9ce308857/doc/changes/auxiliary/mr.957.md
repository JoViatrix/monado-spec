u/json: Add cJSON C++ wrapper.

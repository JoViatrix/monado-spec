os/threading: Add mutex recursive wrapper.

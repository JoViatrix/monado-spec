u/fifo: Doc comments, and small improvements to the C++ wrapper helper.

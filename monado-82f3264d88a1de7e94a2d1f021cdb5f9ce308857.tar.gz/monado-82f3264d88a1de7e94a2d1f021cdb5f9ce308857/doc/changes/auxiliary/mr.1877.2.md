vk: Name all fence objects with helpers.

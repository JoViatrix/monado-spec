math: Add clock_offset utility to estimate offset between clocks

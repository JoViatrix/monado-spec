u/pp: Pretty print support for new `xrt_input_name` entry,
`XRT_INPUT_GENERIC_PALM_POSE` for `XR_EXT_palm_pose`.

vive: Add shared bindings that are used by @ref drv_vive & @ref drv_survive,
also add mappings/bindings from the Touch controller to the Index Controller so
games only providing Touch bindings works on Index controllers.

u/device: Add default, no-op and not implemented function helpers.

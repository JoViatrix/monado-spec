---
- mr.1971
- mr.2050
---

vk: Add `vk_print_result` helper, used in return checking defines but can also
be used outside of them.

u/config_json: Add functionality to save/load gui state to file.

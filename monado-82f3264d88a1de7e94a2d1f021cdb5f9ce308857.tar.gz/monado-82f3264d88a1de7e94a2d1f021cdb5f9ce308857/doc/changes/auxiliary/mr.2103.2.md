u/native_images_debug: Add `u_native_images_debug` and `u_swapchain_debug` to
debug `xrt_image_native` and `xrt_swapchain_native` content.

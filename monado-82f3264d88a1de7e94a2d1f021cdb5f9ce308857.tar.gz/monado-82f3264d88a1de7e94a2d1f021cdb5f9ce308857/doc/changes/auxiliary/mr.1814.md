u/debug_gui: Small refactor of loop and and tracing.

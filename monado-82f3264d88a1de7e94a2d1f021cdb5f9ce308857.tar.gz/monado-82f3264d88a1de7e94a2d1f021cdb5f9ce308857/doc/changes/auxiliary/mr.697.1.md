u/trace_marker: Add trace marker support code, this code uses the Linux
trace_marker kernel support to enable Monado to trace both function calls and
other async events.

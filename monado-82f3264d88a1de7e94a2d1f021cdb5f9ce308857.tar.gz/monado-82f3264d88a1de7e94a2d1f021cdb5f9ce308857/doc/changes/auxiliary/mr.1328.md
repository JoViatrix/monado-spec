cmake: Split the CMakeLists.txt out into the sub-directories of each library,
making each much more manageable when editing. 

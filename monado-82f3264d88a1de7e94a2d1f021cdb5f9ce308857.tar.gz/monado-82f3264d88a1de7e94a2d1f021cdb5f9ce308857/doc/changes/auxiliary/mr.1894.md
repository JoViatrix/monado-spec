vk: Add and use enumeration helpers.

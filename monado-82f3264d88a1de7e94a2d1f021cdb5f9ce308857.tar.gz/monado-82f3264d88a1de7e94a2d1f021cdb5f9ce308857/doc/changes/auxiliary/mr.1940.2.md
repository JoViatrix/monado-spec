vk: Add string return function for VkSharingMode.

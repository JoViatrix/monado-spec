u/frame_times_widget: Optimize FPS calculation using precomputed frame timings.

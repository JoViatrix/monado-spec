u/system_helpers: Add static system device helper.

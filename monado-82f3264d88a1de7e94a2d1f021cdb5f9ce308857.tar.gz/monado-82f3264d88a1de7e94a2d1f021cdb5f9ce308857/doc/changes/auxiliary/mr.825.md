t/fm: Add simple FrameMat that wraps a cv::Mat, this allows us to easily pass
cv::Mat's around without the C code needing to know about OpenCV.

u/logging: Add logging sink to intercept log messages.

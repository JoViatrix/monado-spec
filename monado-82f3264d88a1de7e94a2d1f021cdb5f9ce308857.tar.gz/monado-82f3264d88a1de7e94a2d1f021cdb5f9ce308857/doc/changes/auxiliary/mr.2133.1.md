a/math: Fixes const-correctness in m_relation_history

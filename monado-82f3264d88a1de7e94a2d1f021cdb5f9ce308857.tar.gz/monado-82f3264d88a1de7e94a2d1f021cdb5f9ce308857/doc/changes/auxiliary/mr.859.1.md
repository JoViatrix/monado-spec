t/calibration: Add support for RGB image streams, also add a special sink
converter helper to handle this case.

u/sink: Add a combiner sink that combines two frames into a stereo frame

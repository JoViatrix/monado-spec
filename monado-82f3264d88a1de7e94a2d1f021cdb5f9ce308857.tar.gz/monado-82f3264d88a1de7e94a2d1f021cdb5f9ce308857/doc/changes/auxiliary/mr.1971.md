vk: Use VK_CHK_WITH_RET instead of vk_check_error.

---
- mr.840
---

u/trace_marker: Switch from homegrown tracing code to using Percetto/Perfetto.

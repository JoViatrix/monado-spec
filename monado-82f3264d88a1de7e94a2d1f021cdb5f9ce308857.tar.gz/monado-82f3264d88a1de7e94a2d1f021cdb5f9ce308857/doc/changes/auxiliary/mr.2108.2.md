u/pacing: Split submit timing into begin and end.

vk: Add two call helper for getting instance extensions, and use it.

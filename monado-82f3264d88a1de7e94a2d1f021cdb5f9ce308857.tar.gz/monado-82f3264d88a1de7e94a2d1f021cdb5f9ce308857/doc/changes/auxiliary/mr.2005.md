vk: Add debug inserting helper function and use it for inserting renderdoc frame delimiter in vk client

u/pacing: Add vblank timing function for display control, lets the fake pacer
properly synchronise with hardware.

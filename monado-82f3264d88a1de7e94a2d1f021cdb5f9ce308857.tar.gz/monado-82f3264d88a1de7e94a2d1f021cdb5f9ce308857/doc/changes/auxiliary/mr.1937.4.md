t/slam: Add reset state button

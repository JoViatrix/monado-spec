u/linux: Add code that raises the priority of the calling thread to realtime,
requires the process to be run as root or have `CAP_SYS_NICE` set.

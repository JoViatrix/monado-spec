android: Tidy code and add warning on not getting refresh rate.

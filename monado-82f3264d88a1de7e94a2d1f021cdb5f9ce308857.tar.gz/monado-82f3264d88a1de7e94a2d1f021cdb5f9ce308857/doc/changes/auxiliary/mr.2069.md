misc: Fix double free when shrinking typed array to zero.

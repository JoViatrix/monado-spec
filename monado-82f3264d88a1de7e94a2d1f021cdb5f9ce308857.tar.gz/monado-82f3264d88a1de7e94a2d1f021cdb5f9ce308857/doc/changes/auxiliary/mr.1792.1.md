vive: Tidy the files a lot, break the calibration getters out into own file.

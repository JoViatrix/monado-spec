u/pacing: Add env variable to set present to display offset.

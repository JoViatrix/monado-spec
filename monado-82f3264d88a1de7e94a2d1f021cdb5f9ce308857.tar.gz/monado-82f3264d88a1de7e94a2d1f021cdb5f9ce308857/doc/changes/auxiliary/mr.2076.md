---
- mr.2076
- mr.2084
---

u/pacing: Add option U_PACING_APP_USE_MIN_FRAME_PERIOD to allow selecting the
minimal frame period instead of calculated for pacing. The app is still being
throttled, it's just different.

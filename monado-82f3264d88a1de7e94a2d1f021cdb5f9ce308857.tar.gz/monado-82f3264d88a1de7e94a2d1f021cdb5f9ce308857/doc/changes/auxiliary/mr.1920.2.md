d3d: Add copy D3D12 helper functions, needed to work around issues with layout
on small textures on NVidia hardware.

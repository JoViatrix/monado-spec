a/bindings: Adds support for `XR_EXT_hand_interaction` profile - Updates
bindings & pretty-print for newly added support for `XR_EXT_hand_interaction`
profile.

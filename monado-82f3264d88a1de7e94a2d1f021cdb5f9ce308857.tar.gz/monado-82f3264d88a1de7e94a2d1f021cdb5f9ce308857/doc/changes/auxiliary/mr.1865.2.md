---
- mr.1879
---

u/logging: Truncate the output of hexdump at a safer limit (16MB).

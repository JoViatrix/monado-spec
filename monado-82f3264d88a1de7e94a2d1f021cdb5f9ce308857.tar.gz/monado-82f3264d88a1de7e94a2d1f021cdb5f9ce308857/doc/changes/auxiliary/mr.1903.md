bindings: Add system buttons to WinMR controllers, for OpenXR gate them behind
the XR_MNDX_system_buttons extension.

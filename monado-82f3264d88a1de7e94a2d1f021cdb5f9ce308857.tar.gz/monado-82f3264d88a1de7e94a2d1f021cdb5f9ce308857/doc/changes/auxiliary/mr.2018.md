u/space: Add local_floor to legacy helper function, making most builders support
it automatically.

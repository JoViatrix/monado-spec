u/pacing: General improvements.

u/system_helpers: Refactor hand-tracker helper getters.

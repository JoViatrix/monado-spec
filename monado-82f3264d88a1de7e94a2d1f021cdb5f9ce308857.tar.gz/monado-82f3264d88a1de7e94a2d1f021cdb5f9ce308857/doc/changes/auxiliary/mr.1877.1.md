vk: Add helper function to name Vulkan objects using VK_EXT_debug_marker, useful
when debugging validation errors.

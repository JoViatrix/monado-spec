u/live_stats: Add helper to do live statistics on nano-seconds durations.

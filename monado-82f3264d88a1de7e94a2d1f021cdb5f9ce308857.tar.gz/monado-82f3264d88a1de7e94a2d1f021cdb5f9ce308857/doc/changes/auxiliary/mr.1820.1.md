vk: Expand readback pool to be able to set Vulkan format.

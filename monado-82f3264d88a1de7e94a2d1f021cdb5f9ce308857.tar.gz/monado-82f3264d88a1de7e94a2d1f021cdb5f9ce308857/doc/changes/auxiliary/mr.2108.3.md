u/pacing: Keep track of frame times in fake pacer.

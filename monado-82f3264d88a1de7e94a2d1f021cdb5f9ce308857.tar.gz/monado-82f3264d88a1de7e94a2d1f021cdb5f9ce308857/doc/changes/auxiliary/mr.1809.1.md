u/time: Add helper to go from milliseconds to nanoseconds.

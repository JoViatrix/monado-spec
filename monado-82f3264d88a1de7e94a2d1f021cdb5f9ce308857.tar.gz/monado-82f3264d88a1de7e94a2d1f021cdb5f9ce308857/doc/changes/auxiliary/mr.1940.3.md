vk: Add string return functions for bitfield values, also improving the old
bitfield string functions. The new way lets the caller deal with unknown bits.

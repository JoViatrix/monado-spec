main: Fix multiple thread access to VkQueue in present.

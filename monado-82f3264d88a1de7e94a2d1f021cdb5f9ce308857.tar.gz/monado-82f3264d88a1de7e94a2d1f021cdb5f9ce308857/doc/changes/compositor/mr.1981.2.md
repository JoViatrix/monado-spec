main: Wire up timewarp on the graphics path for the distortion shaders.

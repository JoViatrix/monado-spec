client: Support for OpenGL client applications on Windows.

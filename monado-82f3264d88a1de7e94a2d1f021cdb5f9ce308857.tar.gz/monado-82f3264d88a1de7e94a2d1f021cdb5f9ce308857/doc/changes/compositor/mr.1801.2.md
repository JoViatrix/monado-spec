---
- mr.1801
- mr.1820
---

main: Refactor frame handling, makes semantics clearer.

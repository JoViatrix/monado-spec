main: Do not use the global command buffer pool.

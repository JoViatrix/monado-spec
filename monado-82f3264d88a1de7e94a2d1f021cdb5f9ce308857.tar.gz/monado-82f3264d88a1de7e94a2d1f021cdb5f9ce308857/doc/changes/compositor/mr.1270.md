main: Make `VK_KHR_external_[fence|semaphore]_fd` optional, this is helpful for
CI where only lavapipe can be used which does not support those extensions.

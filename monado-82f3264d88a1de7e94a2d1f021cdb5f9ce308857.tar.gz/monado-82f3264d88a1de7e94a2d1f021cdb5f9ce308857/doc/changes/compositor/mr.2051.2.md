multi: Implement display refresh rate functions.

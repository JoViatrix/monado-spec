render: Refactor out into own library.

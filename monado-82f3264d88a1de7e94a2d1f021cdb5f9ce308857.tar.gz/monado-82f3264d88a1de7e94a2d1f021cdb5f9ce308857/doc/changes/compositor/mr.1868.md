client: Wait till D3D12 images aren't in use before releasing the swapchain.

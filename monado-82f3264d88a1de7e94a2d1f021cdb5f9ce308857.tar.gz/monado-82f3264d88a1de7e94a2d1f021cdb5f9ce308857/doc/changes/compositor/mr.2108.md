main: Split submit timing into begin and end.

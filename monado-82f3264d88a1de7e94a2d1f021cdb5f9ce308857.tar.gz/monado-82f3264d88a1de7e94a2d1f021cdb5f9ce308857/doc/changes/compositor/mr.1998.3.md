render|util: Implement equirect2 layer for compute render pipeline.

main: Use at least 3 vk images for comp target swapchain if supported.

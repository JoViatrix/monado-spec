main: Refactor the various getters of poses and view data so that they are
shared between both graphics and compute paths.

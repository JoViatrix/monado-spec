main: Use new graphics layer squasher.

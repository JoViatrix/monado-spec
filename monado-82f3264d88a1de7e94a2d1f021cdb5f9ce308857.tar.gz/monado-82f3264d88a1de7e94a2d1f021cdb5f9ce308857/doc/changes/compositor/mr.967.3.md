main: Increase the usage of the `get_vk` helper function.

client: Remove event functions.

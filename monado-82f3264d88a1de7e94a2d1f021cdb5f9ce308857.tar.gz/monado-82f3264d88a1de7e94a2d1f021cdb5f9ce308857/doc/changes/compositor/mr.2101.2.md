util: Refactor how arguments are given, this makes it easier to change the
number of views that the code supports.

render: Don't enable depth testing and writing for mesh shader.

render: Use defines helpers from Vulkan helper code instead of defining self.

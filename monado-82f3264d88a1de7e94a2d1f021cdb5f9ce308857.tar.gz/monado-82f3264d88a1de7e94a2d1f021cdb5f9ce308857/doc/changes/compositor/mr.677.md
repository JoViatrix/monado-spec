comp: Fix layer submission on nvidia tegra.

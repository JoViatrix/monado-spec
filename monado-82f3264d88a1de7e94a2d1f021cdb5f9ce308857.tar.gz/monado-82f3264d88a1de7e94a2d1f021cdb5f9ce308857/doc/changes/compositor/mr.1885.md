util: Improve Vulkan instance creation code to be clearer about what extensions
are missing, also generally refactor function to make it better.

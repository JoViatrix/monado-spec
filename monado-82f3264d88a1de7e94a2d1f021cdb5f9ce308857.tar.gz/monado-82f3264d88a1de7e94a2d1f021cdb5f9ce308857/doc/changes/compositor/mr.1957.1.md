main: Trace mirror blit function.

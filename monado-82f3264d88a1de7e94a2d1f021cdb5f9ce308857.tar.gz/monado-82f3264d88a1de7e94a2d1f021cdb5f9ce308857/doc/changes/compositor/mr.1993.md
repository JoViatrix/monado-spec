client: Make it possible to set log level in Vulkan compositor.

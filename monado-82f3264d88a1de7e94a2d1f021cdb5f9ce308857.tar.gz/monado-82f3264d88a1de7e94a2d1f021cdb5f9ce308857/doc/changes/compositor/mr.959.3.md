render: Lots of refactoring and tidying in code, making it independent of the
compositor and only depending on the vk_bundle.

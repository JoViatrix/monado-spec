---
- issue.120
- mr.787
---

main: Make it possible to create the swapchain later when actually needed,
and have the swapchain be in a non-ready state that stops drawing.

render: Refactor mesh distortion dispatch functions.

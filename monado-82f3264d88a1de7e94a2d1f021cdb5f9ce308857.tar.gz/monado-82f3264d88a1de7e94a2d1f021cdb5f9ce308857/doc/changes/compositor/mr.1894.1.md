util: Use enumeration helpers, with a tiny little bit of refactor to increase
code reuse.

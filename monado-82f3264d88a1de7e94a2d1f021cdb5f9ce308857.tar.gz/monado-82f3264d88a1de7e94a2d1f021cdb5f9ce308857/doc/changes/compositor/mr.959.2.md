render: Add fast path for single layer projection layer skipping the layer
renderer and avoiding one copy.

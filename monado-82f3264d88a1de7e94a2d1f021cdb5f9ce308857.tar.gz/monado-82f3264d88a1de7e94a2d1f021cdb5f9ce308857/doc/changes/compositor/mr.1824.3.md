util: Remove samplers from comp_swapchain_image, they where alsways the same.

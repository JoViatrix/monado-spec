client: Add and use helpers to unwrap native swapchains and compositors.

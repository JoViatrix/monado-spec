client: Add renderdoc_enabled implementation for vk/gl only on android platform

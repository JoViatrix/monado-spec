main: Name the runtime Surface on Android.

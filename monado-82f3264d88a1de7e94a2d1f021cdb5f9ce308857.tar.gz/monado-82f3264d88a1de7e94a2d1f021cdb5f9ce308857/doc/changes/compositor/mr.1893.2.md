main: Only wait on the main queue when drawing the frame.

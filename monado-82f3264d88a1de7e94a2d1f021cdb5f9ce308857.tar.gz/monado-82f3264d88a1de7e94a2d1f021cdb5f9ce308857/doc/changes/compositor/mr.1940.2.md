main: Free plane_properties earlier.

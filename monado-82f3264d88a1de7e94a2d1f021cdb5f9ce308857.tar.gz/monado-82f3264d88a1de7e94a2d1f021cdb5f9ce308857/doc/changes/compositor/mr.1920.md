client: Use D3D12 allocator, and work around NVidia bug.

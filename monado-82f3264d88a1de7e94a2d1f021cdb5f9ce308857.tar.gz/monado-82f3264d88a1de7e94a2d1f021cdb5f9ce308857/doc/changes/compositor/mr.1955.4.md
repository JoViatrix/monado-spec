render: Optimize layer shader, cutting of around 5%-10% of execution time.

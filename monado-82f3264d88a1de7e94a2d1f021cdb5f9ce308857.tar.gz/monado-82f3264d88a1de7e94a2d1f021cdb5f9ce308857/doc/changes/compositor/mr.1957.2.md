util: Generate limited limited ids for native swapchains.

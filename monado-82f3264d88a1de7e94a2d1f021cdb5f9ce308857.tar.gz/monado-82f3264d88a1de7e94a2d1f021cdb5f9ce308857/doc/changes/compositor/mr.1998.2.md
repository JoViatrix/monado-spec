shaders: Use fma in compute shader.

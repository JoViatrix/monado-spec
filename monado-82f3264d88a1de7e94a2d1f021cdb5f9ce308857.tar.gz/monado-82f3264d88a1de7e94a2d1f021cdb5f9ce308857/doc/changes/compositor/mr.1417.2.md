main: Propagate more errors from the renderer frame drawing and helper mirror
functions.

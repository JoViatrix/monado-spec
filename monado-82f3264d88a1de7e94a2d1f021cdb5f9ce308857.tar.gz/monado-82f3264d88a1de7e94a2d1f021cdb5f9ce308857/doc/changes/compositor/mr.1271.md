main: Add thread waiting for vblank events, lets the fake pacer properly
synchronise with hardware.

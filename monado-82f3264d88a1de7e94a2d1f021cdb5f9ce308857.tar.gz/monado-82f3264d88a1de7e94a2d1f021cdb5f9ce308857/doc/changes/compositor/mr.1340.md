d3d12: Initial support for D3D12 client applications on Windows.

---
- mr.1417
- mr.2052
---

util: Completely propagate errors from image creation failures and some tidy.

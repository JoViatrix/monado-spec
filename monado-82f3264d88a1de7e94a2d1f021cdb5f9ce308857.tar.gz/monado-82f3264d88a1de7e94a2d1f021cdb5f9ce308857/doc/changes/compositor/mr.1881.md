multi: Try to set realtime priority on main thread

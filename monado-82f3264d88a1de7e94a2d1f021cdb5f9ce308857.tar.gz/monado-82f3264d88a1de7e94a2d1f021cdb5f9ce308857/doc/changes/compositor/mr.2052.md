util: Also clean up image views on mutex and cond variable creation error
in the comp_swapchain.c file.

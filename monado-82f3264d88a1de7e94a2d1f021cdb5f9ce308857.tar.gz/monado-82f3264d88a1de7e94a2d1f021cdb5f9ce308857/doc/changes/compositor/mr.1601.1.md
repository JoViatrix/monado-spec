main: Refactor arguments to `comp_target_create_images`, introduces the struct
`comp_target_create_images_info`.

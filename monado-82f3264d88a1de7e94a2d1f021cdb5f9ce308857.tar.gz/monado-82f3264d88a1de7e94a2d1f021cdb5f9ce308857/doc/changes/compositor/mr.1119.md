---
- mr.1119
- mr.1124
- mr.1125
- mr.1128
---

client/util: Fix several flags being set wrong on barriers and creation of the
swapchain images. We were especially wrong with the depth stencil formats.

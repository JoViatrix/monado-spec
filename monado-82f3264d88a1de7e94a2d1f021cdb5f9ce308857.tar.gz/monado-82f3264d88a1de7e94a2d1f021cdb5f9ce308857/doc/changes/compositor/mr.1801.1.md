main: Refactor to use vk_surface_info helper.

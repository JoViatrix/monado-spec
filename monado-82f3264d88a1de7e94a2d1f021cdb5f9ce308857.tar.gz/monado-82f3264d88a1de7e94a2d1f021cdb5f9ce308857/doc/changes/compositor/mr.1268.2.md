main: Setting logging level when checking vulkan caps.

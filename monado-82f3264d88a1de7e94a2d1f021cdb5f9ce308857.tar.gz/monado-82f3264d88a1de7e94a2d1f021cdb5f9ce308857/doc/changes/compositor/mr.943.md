---
- mr.943
- mr.1263
- mr.1295
- mr.1326
- mr.1302
- mr.1337
- mr.1340
---

client: Initial support for D3D11 client applications on Windows.

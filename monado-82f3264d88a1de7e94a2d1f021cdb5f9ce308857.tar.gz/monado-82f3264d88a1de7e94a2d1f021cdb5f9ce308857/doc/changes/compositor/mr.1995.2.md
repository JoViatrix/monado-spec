main: Remove old layer renderer code and integration.

main: Refactor mirror to debug gui code and add support for compute queue.

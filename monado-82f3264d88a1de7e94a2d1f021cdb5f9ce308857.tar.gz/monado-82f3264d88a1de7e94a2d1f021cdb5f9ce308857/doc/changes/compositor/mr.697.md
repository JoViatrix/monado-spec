main: Integrate new frame timing code.

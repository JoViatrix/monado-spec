main: Implement display refresh rates function stubs.

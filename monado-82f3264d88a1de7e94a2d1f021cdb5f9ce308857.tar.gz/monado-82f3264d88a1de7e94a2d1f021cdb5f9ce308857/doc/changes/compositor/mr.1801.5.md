main: Try to detect when we miss frames even without frame timing information.

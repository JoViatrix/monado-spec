render: Stop timewarp stretching by changing math.

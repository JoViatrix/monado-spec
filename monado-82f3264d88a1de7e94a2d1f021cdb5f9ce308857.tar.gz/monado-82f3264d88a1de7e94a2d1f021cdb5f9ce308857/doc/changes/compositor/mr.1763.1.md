client: Use correct format in get_swapchain_create_properties functions, client
compositors are given their formats, make then translate to Vulkan before
passing on.

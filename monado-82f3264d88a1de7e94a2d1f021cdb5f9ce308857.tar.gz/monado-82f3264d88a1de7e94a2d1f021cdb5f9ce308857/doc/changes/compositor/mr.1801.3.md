main: Avoid acquiring early if the target isn't ready.

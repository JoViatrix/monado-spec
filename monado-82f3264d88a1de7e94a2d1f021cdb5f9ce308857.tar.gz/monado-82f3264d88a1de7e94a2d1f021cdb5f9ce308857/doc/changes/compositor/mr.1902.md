main: Set sequence number correctly on readback frames.

util: Prefix compute functions with `cs`, rename file and refactor out layer
helpers in preparation for new graphics layer render code.

null: Remove events code, no longer needed.

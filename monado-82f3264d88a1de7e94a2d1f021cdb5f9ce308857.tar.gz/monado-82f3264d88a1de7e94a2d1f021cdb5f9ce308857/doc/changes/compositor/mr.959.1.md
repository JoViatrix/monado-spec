---
- mr.959
- mr.967
- mr.970
- mr.982
- mr.1021
---

render: Refactor and reorganize compositor to improve modularity and ease of
reuse. This introduces the render folder which aims to be useful Vulkan render
code that can be used outside of the compositor.

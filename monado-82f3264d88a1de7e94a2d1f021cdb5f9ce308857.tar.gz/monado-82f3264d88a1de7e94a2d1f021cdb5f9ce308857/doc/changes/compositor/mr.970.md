util: Add Vulkan helper code to initialise a vk_bundle from scratch.

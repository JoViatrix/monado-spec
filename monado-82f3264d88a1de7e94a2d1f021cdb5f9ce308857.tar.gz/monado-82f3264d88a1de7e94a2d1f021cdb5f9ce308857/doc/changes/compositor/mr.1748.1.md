render: Do not use the global command buffer pool, use `vk_cmd_pool` for
distrion images upload.

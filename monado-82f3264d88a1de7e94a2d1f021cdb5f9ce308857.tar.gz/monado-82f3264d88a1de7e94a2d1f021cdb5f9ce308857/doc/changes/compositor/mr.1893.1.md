main: Add NorthStar to listed displays

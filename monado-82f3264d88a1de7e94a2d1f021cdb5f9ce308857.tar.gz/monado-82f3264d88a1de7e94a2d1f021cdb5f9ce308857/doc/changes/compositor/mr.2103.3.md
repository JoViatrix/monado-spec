main: Use new debuggable scratch images (one `comp_scratch_single_images` per
view), used to drive the preview view in the UI and to debug the views.

---
- mr.1971
- mr.2050
---

main: Use VK_CHK_WITH_RET instead of vk_check_error, and convert a few other
places to the helpers as well.

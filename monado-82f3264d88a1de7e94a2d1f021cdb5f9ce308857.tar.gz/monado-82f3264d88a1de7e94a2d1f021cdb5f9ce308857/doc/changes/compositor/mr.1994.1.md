render: Prepare gfx shared one ubo and src code for addition of cylinder and
equirect2 shaders.

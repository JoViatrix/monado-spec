render: Refactor gfx mesh shader allocation and dispatch.

render: Refactor scratch images so that they are fully their own struct and
is managed by a user of the render code.

client: Handle EGL_NO_CONTEXT_KHR gracefully if the EGLDisplay supports
EGL_KHR_no_config_context.

render: Add ATW support in the compute pipeline.

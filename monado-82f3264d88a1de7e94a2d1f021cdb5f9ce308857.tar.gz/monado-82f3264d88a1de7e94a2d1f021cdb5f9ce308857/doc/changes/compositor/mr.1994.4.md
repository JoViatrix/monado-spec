util: Add cylinder and equirect2 shaders and code for graphics path.

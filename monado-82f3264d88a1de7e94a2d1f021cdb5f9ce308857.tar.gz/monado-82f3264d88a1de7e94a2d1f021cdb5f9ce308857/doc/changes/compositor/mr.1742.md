Android: Refactor surface creation flow.

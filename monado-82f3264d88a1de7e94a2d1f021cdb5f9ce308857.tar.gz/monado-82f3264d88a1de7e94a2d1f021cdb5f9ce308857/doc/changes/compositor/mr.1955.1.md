render: Various smaller commit to tidy the code,
better documentation and naming of defines.

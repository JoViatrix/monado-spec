client: Make sure to not double CloseHandle semaphore HANDLE.

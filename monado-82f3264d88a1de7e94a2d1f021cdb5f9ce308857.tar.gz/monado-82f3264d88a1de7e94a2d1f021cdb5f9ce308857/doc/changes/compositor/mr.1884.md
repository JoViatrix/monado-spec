c/main: Use vk_cmd_submit_locked in vk_helper to simply peek logic 

multi: Switch to use `xrt_session_event` and `xrt_session_event_sink`.

main: Prefer to only have two swapchains, useful for direct mode rendering.

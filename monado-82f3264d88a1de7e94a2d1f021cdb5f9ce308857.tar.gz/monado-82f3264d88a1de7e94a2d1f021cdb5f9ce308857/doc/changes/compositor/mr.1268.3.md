render: Use query pool to measure GPU time.

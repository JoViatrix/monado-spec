main: Do not list VK_FORMAT_A2B10G10R10_UNORM_PACK32 as a supported format, it's
not enough to show linear colours without banding but isn't used that often so
do not list it.

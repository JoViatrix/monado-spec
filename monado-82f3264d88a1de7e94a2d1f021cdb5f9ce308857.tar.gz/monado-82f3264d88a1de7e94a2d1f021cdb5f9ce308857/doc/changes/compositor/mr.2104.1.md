main: Use vk_enumerate_swapchain_images helper.

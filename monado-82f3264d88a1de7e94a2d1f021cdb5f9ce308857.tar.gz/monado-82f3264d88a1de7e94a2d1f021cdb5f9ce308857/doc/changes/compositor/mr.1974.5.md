render: Expose render_calc_uv_to_tangent_lengths_rect function, document it
better and also add tests for it.

client: Silence VK_FORMAT_R32_SFLOAT warning in OpenGL code.

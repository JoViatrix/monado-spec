main: Make sure to not use the array of displays if we fail to allocate it, and
also tidy the code.

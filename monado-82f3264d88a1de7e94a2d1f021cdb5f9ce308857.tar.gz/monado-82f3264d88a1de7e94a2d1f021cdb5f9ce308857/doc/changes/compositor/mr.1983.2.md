render: Add new layer shaders and support code.

---
- mr.1120
- mr.1135
- mr.1144
---

main: Add support for mirroring the left view back to the debug gui, so we can
record it or see what somebody's doing in VR.

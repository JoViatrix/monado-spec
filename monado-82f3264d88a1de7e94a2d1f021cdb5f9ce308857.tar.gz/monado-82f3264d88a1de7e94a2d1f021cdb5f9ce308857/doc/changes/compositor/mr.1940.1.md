main: Use more enumeration helpers.

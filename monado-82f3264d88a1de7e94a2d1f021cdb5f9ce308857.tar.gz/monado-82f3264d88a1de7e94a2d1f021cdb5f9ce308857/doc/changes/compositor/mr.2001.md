util: implement cylinder layer for compute render pipeline

---
- mr.1983
- mr.1994
- mr.1995
- issue.299
- mr.2026
- mr.2105
---

util: Add new graphics layer helper code, supports projection, quad, cylinder
and equirect2 layers. This path now completely replaces the old layer renderer
that was in the main compositor, making it reusable.

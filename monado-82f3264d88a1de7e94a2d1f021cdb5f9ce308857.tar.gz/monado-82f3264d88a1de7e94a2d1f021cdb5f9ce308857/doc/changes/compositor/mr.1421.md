main: Render cube layer

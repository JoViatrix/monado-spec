render: Make it possible to set clear color when starting render pass.

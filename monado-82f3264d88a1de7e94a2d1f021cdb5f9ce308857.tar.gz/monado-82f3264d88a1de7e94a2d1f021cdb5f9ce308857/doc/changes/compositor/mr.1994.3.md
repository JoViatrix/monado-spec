util: Prepare code for addition of cylinder and equirect layers to graphics
paths, like adding various helpers.

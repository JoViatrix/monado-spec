client: Fence the client work and send fence to the native compositor.

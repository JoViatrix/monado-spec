render: Remove old graphics layer squasher.

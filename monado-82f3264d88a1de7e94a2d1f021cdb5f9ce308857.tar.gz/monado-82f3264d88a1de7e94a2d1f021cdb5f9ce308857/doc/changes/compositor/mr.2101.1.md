main: Add enum to select FoV source, it was very unclear where exactly the FoV
came from, this makes it clearer and also reduces the number of places it's
accessed from.

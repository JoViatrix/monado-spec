util: Add `comp_scratch_single_images` and `comp_scratch_stereo_images` helper
struct, these uses `u_native_images_debug` this let us do zero copy viewing or
debugging of the images.

shaders: Add blit compute shader.

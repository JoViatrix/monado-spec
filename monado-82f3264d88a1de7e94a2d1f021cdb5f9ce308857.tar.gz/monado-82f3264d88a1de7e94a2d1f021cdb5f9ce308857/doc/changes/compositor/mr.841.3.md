main: Also resize on VK_SUBOPTIMAL_KHR.

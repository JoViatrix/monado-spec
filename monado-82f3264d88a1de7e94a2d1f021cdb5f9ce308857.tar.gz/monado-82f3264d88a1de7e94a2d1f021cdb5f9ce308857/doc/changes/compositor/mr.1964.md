---
- mr.1964
- mr.2066
---

client: Expose size limit for swapchains.

client: Set default log level on vk_bundle in Vulkan compositor.

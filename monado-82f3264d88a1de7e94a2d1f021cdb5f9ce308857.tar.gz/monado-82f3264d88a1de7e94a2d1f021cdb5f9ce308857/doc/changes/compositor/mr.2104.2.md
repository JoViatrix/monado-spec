main: Improve swapchain creation to print more debug information.

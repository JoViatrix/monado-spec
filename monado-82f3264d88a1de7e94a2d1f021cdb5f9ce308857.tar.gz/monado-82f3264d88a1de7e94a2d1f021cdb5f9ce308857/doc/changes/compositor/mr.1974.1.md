main: Tidy headers in layer renderer.

main: Prepare for submitting work on the compute queue.

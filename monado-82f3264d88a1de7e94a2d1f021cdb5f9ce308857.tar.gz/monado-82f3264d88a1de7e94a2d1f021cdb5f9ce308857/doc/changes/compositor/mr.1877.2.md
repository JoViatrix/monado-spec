main: Name all fence objects using debug helper function.

multi: Add stub set thread hint function.

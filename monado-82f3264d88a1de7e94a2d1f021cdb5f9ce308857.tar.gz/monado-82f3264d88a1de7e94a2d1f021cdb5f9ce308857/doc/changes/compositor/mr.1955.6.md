main: Use new layer squasher helpers and manage scratch images lifetime.

render: Add new shared samplers, use them and remove the default sampler.

main: Refactor graphics dispatch, this makes it easier to extract the code
later down the line.

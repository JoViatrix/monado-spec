util: Replace is_view_index_visible helper by is_layer_view_visible.

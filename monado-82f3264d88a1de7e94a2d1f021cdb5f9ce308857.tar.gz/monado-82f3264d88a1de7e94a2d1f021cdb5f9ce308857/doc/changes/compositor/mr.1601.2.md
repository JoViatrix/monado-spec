main: Refactor how surface formats are handled, this lets the compositor select
which formats are considered exactly, and not just prefer one format.

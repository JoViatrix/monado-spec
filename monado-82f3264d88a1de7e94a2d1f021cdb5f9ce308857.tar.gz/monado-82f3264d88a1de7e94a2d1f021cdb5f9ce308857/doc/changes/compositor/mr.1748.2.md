client: Do not use the global command buffer pool in the Vulkan compositor.

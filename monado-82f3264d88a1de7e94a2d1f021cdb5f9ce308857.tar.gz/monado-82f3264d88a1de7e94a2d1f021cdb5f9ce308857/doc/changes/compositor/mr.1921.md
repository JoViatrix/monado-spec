main: Fix warnings found with GCC 13.

main: Add new compute rendering backend.

main: Add argument to specify display mode id for surface creation.

client: Wait on Vulkan clients to complete rendering.

render: Reuse a single command buffer instead of allocating/freeing it every frame.

multi: Adds support for `XR_EXT_hand_interaction` profile.

---
- issue.47
---

client: Reduce the minimum required OpenGL version for client applications to
3.0.

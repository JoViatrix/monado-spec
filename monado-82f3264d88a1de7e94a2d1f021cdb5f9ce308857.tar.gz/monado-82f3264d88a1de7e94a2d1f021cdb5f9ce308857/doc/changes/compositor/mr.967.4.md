main: Use the new helpers to reduce code in main library.

main: Always use the mode's extents when creating the surface.

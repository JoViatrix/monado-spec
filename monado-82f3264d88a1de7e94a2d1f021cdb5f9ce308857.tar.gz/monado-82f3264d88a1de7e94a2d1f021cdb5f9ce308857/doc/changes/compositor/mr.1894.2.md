---
- mr.1894
- mr.1913
---

main: Use enumeration helpers in and refactor the NVIDIA direct target code.

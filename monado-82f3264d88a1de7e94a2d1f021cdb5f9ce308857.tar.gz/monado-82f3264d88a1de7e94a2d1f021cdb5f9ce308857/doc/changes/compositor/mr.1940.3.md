main: Print creation info for direct mode objects.

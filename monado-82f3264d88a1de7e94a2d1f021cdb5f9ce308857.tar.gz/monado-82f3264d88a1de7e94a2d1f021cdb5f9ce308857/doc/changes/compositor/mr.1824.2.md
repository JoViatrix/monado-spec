main: Use the new samplers on render_resources, remove the layer renderer
framebuffer's samplers.

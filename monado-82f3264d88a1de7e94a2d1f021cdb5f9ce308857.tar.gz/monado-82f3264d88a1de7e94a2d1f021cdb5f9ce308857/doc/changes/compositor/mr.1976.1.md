render: Add ability to sub-allocate UBOs from a larger buffer, both code and
needed scaffolding to use it in the gfx path.

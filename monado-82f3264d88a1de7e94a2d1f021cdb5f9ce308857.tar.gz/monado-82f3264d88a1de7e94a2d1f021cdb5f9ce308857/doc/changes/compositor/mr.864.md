multi: Make sure there are at least some predicted data, to avoid asserts in
non-service mode.

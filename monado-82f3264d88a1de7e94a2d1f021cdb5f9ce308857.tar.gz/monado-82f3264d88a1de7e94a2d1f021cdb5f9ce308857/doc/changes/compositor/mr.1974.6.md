render: Tweak cmake files so that comp_render is usable without any other of
the compositor bits.

main: Optionally enable VK_EXT_debug_marker extension on debug builds.

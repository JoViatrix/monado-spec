client: Refactor out the connection connect code into a its own file, this lets
it be reused by other things that might want to connect like monado-ctl and
libmonado.

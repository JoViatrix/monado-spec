all: Adds support for `XR_EXT_hand_interaction` profile - plumbs extension
enabled state to ipc server/drivers.

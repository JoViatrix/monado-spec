shared: Change IPC script to automatically mark all input aggregates as const.

---
- mr.1525
- mr.1531
- mr.1584
- mr.1807
---

all: Add Windows support to the IPC layer, this is based on named pipes.

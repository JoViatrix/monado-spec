server: Destroy the shared memory area when shutting down.

Android: Do not require OPENXR permission when connect MonadoService.
Permission will not be granted if install application before permission
container.

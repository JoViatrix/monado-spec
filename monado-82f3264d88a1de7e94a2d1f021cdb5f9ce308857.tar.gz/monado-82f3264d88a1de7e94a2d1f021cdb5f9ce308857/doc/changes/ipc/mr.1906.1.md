shared: Add function to unmap the shared memory area when destroying.

steamvr_lh: Add Vive Pro support.

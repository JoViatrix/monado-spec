euroc: Add euroc driver that plays EuRoC datasets for SLAM system evaluation.

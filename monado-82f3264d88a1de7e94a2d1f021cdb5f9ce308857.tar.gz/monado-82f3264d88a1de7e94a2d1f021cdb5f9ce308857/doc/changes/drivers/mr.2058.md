adjust the pose for VIT system and assumes basalt

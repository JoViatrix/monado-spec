wmr: Send calibration automatically to SLAM tracker. This makes WMR SLAM
tracking work out of the box without user intervention with Basalt.

steamvr_lh: Add additional bindings for vive and index controllers.

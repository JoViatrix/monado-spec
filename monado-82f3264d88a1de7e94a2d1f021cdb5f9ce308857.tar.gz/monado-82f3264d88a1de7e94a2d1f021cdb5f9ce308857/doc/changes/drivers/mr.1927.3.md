steamvr_lh: Add Valve Knuckles support, also support hand tracking.

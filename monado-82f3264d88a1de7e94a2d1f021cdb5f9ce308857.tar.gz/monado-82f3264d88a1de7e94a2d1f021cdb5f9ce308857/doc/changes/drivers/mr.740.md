vive: Setup the variable tracking for imu fusion.

vive: Refactor timing code in source, make it take in account of the age of
samples, this reduces the time drift due to irregular delivery of packets.

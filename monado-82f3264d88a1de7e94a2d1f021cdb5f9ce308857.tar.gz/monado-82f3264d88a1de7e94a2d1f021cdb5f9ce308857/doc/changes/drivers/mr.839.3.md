north_star: General improvement of code organization.

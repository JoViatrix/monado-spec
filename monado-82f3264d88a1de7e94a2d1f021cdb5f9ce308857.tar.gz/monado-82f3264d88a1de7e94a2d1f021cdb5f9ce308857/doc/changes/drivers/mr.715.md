vf: Show the time on the video test source video server.

multi: Enable specifying arbitrary xrt_input_name for querying tracker poses.

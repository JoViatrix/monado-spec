nreal_air: Tidy and silence warnings.

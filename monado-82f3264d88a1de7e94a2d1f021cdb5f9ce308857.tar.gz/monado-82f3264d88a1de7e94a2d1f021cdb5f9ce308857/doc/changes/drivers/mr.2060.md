---
- mr.2060
- mr.2061
---

remote: Fix socket closing on Windows by using socket_close.

vf: Some tidy, frame fixes and tracing support.

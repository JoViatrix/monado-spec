steamvr_lh: Fix prediction and jitter and remove old `LH_PREDICTION` env var.

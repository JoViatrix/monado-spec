remote: Add support for local_floor space.

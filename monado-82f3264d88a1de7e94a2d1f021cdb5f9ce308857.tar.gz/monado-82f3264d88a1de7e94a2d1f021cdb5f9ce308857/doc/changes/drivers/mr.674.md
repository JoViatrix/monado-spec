vive: Factor out json config parser and reuse it in survive driver.

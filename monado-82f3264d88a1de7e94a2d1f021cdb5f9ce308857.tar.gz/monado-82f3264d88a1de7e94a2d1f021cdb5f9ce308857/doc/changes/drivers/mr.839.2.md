north_star: Fixes the FOV calc on the v1/3D distortion.

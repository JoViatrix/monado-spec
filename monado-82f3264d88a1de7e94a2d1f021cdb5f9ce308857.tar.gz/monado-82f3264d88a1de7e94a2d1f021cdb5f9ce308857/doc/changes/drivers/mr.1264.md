wmr: Add initial hand tracking for WMR devices.

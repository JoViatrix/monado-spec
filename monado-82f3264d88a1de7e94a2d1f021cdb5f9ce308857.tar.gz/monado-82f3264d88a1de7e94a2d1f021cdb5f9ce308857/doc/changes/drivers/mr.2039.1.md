all: Use `u_device_noop_update_inputs` helper for drivers with nothing in their
update input function.

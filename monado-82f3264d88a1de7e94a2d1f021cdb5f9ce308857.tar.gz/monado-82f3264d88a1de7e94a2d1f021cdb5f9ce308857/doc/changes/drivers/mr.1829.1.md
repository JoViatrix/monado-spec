vive: Drian IMU packets at start, this helps reduce time drift due backed up
packets confusing the timing code.

wmr: Add auto exposure and gain module.

d/wmr: Properly compute hand tracking boundary circle

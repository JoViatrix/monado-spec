vive: Set the correct tracking origin type when we have SLAM.

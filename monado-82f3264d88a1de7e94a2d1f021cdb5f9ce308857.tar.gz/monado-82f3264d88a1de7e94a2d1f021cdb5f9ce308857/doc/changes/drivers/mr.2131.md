---
- mr.2131
- mr.2143
---
d/{wmr,rift_s,vive,ns}: Share hand bounding box with head tracker

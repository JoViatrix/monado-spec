vive: Tidy code by improving comments, removing old print, and use defines for
hardcoded values.

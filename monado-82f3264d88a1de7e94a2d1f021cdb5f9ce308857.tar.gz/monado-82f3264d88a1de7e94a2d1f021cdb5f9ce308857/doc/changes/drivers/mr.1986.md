steamvr_lh: Silence some useless logging and properly wait for vive wands to settle

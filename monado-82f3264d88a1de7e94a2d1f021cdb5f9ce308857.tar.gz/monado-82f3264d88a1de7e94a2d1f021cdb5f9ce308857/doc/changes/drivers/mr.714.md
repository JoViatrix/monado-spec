---
- mr.714
- mr.1789
- mr.1926
---

qwerty: Add qwerty driver for emulating headset and controllers with mouse and
keyboard.

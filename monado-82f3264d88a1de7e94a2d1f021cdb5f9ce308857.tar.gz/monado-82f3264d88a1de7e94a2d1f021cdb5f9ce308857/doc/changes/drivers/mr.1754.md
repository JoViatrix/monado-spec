wmr: Move driver over to builder interface. Currently only a simpler builder,
the SLAM and Hand-Tracking setup hasn't been moved out yet.

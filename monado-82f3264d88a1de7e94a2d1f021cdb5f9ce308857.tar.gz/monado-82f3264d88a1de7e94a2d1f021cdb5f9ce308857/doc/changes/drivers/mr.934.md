depthai: Extend driver to support stereo grayscale cameras

steamvr_lh: Fix warnings with logger defines.

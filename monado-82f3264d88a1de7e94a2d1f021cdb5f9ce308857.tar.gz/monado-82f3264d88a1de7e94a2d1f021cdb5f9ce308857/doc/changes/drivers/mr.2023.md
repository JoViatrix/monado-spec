wmr: Add Dell Visor support to WMR driver.

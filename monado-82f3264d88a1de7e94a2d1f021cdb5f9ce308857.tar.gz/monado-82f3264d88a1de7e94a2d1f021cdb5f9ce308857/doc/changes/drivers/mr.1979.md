steamvr_lh: Add tundra as a generic tracker

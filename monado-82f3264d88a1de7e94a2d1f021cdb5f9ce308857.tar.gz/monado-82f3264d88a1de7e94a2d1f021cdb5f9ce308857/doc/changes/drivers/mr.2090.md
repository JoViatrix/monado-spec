steamvr_lh: Simplify coordinate space conversion.

realsense: Expand driver to support non-T26x cameras and external SLAM tracking.

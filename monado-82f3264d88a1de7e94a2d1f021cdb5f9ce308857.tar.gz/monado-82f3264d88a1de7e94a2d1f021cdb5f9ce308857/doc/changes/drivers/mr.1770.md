dai: Add manual exposure controls via u_var tracking.

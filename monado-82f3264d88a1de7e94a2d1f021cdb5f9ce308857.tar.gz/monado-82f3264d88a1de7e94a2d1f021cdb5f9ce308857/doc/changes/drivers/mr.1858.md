wmr: Improve WMR controller orientation when in 3DoF by using the information
that is available in the JSON config that is stored on the controllers.

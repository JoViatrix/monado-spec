steamvr_lh: Add a mutex to update_inputs() to prevent unsafe condition in lighthouse driver.

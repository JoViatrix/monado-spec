wmr: Reduce drifting by applying calibration biases to controllers, doesn't
fully eliminate as calibration is lacking for all temperature ranges.

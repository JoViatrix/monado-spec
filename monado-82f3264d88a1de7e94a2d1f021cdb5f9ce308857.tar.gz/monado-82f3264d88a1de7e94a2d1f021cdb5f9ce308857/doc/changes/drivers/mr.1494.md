---
- mr.1494
- mr.1832
---

dai: Enable IR floodlight, add code and env variable and u_var tracking to
control it's level.

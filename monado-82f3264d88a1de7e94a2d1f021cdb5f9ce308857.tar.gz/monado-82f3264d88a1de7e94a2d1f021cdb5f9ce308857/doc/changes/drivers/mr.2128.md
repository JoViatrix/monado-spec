survive: Fall back to default ipd if survive reports 0.0

steamvr_lh: Add Index support, also support canting of views.

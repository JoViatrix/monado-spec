wmr: Add SLAM (6dof inside-out) tracking for WMR headsets.

steamvr_lh: Use proper timestamp on hands and fixes to angular/ linear velocity handling.

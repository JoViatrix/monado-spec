opengloves: Refactor creation.

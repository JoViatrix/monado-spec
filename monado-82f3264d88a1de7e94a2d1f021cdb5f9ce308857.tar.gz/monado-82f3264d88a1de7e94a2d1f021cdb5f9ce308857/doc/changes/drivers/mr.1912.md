android: Fixed the issue of screen stuttering on some Android devices caused by
failing to set the IMU event rate.

d/vive: Use raw imu samples for slam

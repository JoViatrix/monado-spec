ohmd: Support OpenHMD controllers and specifically the Oculus Touch controller.

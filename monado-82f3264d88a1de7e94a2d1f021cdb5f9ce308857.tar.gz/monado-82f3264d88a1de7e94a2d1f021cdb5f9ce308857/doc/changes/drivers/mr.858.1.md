v4l2: Add tracing support.

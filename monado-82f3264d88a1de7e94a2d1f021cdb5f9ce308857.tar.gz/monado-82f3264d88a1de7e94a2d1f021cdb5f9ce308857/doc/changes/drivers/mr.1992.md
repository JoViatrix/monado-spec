remote: Add support for new dynamic device roles.

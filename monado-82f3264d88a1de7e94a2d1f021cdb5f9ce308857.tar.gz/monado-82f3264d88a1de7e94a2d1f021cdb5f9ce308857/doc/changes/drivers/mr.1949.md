d/na,d/vive: Reduce relation history lock contention

depthai: Add tracing support.

pssense: Add trigger force feedback.

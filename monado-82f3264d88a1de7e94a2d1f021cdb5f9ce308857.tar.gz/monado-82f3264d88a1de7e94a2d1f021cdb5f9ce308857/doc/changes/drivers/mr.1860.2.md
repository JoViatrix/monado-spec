---
- mr.1860
- mr.1863
---

vive: Add support for Gen 3.0 and Tundra trackers.

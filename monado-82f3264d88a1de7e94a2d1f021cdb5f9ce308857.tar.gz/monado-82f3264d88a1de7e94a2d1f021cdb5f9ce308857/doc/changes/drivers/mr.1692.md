dai: Make DepthAI frameserver work with multicam sinks.

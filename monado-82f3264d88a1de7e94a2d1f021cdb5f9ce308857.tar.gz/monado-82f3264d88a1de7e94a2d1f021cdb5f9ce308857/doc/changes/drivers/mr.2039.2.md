all: Standardize use of `u_device_get_view_poses` helper.

north_star: Upstreams Moses Turner's "VIPD" distortion.

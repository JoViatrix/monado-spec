qwerty: Fix input timestamps for select and menu.

psvr: Ensure that timestamps are always after each other, stopping any
time-traveling sample packets.

simulated: Support reference space usage via debug printing.

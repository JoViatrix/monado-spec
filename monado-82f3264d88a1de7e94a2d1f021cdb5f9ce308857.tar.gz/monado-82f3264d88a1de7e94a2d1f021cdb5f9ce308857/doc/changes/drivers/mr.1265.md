survive/vive: Use new common controller bindings in `a/vive`.

north_star: Improved JSON parsing.

dai: Add EuRoC recorder integration.

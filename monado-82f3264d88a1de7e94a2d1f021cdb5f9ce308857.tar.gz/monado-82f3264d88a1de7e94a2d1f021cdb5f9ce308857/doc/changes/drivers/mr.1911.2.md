survive: Add support for HTC Vive Pro 2

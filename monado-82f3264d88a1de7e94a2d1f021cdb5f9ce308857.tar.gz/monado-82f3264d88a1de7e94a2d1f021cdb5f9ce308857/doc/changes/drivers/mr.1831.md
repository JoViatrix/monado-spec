ht: Error out if we can't find a hand-tracking model directory.

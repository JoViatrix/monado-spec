vive: Minor refactor to IMU conversion code, should be no functional change.

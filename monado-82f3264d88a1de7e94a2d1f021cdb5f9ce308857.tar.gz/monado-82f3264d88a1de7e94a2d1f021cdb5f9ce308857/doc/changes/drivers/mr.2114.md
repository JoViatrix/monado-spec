steamvr_lh: Make playspace reading more robust by choosing the first tracking univere from
lighthousedb.json that is found in chaperone_info.vrchap.

wmr: Add `WMR_LEFT_DISPLAY_VIEW_Y_OFFSET` and `WMR_RIGHT_DISPLAY_VIEW_Y_OFFSET`
environmental variables to adjust screen distortion.

rs: Fix warnings with function declarations.

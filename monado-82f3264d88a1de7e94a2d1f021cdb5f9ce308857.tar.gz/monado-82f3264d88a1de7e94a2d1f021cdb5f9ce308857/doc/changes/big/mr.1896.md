xrt: Updates binding verify usage for new binding code gen and pass in enabled
extensions status.

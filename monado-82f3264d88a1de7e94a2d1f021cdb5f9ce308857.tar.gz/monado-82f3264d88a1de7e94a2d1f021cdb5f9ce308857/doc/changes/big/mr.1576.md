---
- mr.1576
- mr.1577
- mr.1579
- mr.1598
- mr.1827
---

Added [Tracy](https://github.com/wolfpld/tracy) as a supported tracing backend,
it joins the [Perfetto](https://perfetto.dev/) backend. Tracy works on Windows,
but doesn't support full system tracing or multi app as well as Perfetto.

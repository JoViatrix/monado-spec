Add hot-switch support for input devices like controllers and gamepads. This is
not full hot-plug support, but instead only enables switching between devices
created at start.

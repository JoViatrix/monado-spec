---
- mr.1908
- mr.2055
- mr.2099
---

Add `libmonado` library, allows control of applications and devices. Exposed API
follows semver and is semi-stable. Will never be changed in a backward
incompatible way without increasing the major version. Provisions for easily and
safely checking version is included, both at compile and runtime.

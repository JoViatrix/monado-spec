Add driver for Rokid and Rokid Max glasses, the devices features 3dof tracking.

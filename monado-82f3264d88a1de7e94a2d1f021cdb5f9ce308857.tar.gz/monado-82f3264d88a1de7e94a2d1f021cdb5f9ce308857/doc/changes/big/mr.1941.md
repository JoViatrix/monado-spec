Add new curated debug GUI, while not exposing all the of the knobs it presents
those knobs in a more organized way compared to the advanced UI. The curated UI
also features the readback sink in the background, making it possible for it
to double as the peek window.
